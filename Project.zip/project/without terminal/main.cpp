#include <iostream>
#include <fstream>
#include "stdlib.h"
#include <iomanip>

using namespace std;

unsigned char buffer[8*1024];    // Buffer to hold the machine code
int counter=0;
void emitError(char *s)
{
    cout << s;
    exit(0);
}


void instDecExec(unsigned int instWord)
{
    unsigned int rd, rs1, rs2, funct3, funct7, opcode;
    int I_imm, S_imm, B_imm, U_imm, J_imm;
    unsigned int address;


    opcode = instWord & 0x0000007F;
    rd = (instWord >> 7) & 0x0000001F;
    funct3 = (instWord >> 12) & 0x00000007;
    funct7= (instWord>>25) & 0x3F;
    rs1 = (instWord >> 15) & 0x0000001F;
    rs2 = (instWord >> 20) & 0x0000001F;



    if (opcode == 0b0110011) {   // R type Instructions
        switch (funct3) {
            case 0b0: if (funct7 == 0b0100000) {
                cout << "\tSUB\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
                //regs[rd] = regs[rs1] - regs[rs2];
            }
            else {
                cout << "\tADD\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
                //            regs[rd] = regs[rs1] + regs[rs2];
            }
                break;
            case 0b1:
                cout << "\tSLL\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
                break;
            case 0b10:
                cout << "\tSLT\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
                break;
            case 0b11:
                cout << "\tSLTU\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
                break;
            case 0b100:
                cout << "\tXOR\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
                break;
            case 0b101: if (funct7 == 0b0100000) {
                cout << "\tSRA\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
            }
            else {
                cout << "\tSRL\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
            }
                break;
            case 0b110:
                cout << "\tOR\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
                break;
            case 0b111:
                cout << "\tAND\tx" << rd << ", x" << rs1 << ", x" << rs2 << "\n";
                break;
            default: cout << "\tUnkown R Instruction \n";
        }
    }
    else if (opcode == 0b0010011) // I type Instructions
    {
        I_imm=((instWord>>20)&0x7FF)|(((instWord>>31)?0xFFFFF800:0x0));
        switch (funct3) {
            case 0b0:
                cout << "\tADDI\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
                break;
            case 0b1:

                cout << "\tSLLI\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
                break;
            case 0b10:
                cout << "\tSLTI\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
                break;
            case 0b11:
                cout << "\tSLTIU\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
                break;
            case 0b100:
                cout << "\tXORI\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
                break;
            case 0b101: if (funct7 == 0b0100000) {

                cout << "\tSRAI\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
            }
            else {

                cout << "\tSRLI\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
            }
                break;
            case 0b110:
                cout << "\tORI\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
                break;
            case 0b111:
                cout << "\tANDI\tx" << rd << ", x" << rs1 << ", " << I_imm << "\n";
                break;
            default: cout << "\tUnkown I Instruction \n";
        }
    }
    else if (opcode == 0b0000011) //  Load Type Instructions
    {

        switch (funct3) {
                I_imm=((instWord>>20)&0x7FF)|(((instWord>>31)?0xFFFFF800:0x0));
            case 0b0:
                cout << "\tLB\tx" << rd << "," << I_imm << ",(x" << rs1 << ")" << "\n";
                break;
            case 0b1:
                cout << "\tLH\tx" << rd << "," << I_imm << ",(x" << rs1 << ")" << "\n";
                break;
            case 0b10:
                cout << "\tLW\tx" << rd << "," << I_imm << ",(x" << rs1 << ")" << "\n";
                break;
            case 0b100:
                cout << "\tLBU\tx" << rd << "," << I_imm << ",(x" << rs1 << ")" << "\n";
                break;
            case 0b101:
                cout << "\tLHU\tx" << rd << "," << I_imm << ",(x" << rs1 << ")" << "\n";
                break;
            default:
                cout << "\tUnkown Load Instruction \n";
                break;
        }
    }
    else if (opcode == 0b0100011) // Store Type Instuctions
    {
        S_imm=(((instWord>>7)&0x1f) |((instWord>>24)&0x7f));

        switch (funct3) {
            case 0b0:
                cout << "\tSB\tx" << rd <<" , "  << S_imm << "(x" << rs1 << ")" << "\n";
                break;
            case 0b1:

                cout << "\tSH\tx" << rd <<" , "  << S_imm << "(x" << rs1 << ")" << "\n";
                break;
            case 0b10:

                cout << "\tSW\tx" << rd <<" , "  << S_imm << "(x" << rs1 << ")" << "\n";
                break;
            default:
                cout << "\tUnkown Store Instruction \n";
                break;
        }
    }
    else if (opcode == 0b1100011) // SB Type Instuctions
    {
        int imm=(((instWord>>8)&0xf)|((instWord>>25)&0x3f)|((instWord >>7)&0x1)|((instWord>>31)&0x1));
        switch (funct3) {
            case 0b0:
                counter ++;
                cout << "\tBEQ\tx" << rs1 << ", x" << rs2 << ",  label" << counter <<"\n";
                break;
            case 0b1:
                counter ++;
                cout << "\tBNE\tx" << rs1 << ", x" << rs2 << ",  label"<< counter << "\n";
                break;
            case 0b100:
                counter ++;
                cout << "\tBLT\tx" << rs1 << ", x" << rs2 << ",   label"<< counter  << "\n";
                break;
            case 0b101:
                counter ++;
                cout << "\tBGE\tx" << rs1 << ", x" << rs2 << ",   label"<< counter <<"\n";
                break;
            case 0b110:
                counter ++;
                cout << "\tBLTU\tx" << rs1 << ", x" << rs2 << ", x, label"<< counter  << "\n";
                break;
            case 0b111:
                counter ++;
                cout << "\tBGEU\tx" << rs1 << ", x" << rs2 << ", x, label" << counter <<"          "<<imm<< "\n";
                break;
            default:
                cout << "\tUnkown SB Instruction \n"<<funct3;
                break;
        }
    }
    else if (opcode == 0b0110111) // U Type Instuctions
    {
         U_imm=((instWord>>12)&0xFFFFF);
        cout << "\tLUI\tx" << rd << ", 0x" << U_imm << "\n";
    }
    else if (opcode == 0b0010111) // U Type Instuctions
    {  U_imm=((instWord>>12)&0xFFFFF);
        cout << "\tAUIPC\tx" << rd << ", x" << U_imm << "\n";
    }
    else if (opcode == 0b1101111) // J Type Instuctions
    {
        J_imm= ((instWord>>21)&0x000003FF) + ((instWord>>20)& 0x0000001) + ((instWord>>12)&0x000000FF) + ((instWord>>31)&0x00000001);

        cout << "\tJAL\tx" << rd << ", " << J_imm << "\n";
    }
    else if (opcode == 0b1100111) // J Type Instuctions
    {
        J_imm=((instWord>>20)&0xFFF)|(((instWord>>31)?0xFFFFF800:0x0));
        cout << "\tJALR\tx" << rd << ", x" << rs1 << ", x" << J_imm << "\n";
    }

    else if (opcode == 0b1110011) // ecall/ ebreak Instuctions
    {
        switch (funct3) {
                I_imm=((instWord>>20)&0x7FF)|(((instWord>>31)?0xFFFFF800:0x0));
            case 0b0:

                switch (funct7) {
                    case 0b0:
                        cout << "\tECALL\t" << "\n";
                        break;
                    case 0b1:
                        cout << "\tEBREAK\t"<<"\n";
                    break;}
                break;
            case 0b1:
                cout << "\tCSRRW\tx" <<rd<< ", " << I_imm<< ", x" << rs1<< "\n";
                break;
            case 0b10:
                cout << "\tCSRRS\tx" <<rd<< ", " << I_imm<< ", x" << rs1<< "\n";
                break;
            case 0b11:
                cout << "\tCSRRC\tx" <<rd<< ", " << I_imm<< ", x" << rs1<< "\n";
                break;
            case 0b101:
                cout << "\tCSRRWI\tx" <<rd<< ", " << I_imm<< ", x" << rs1<< "\n";
                break;
            case 0b110:
                cout << "\tCSRRSI\tx" <<rd<< ", " << I_imm<< ", x" << rs1<< "\n";
                break;
            case 0b111:
                cout << "\tCSRRCI\tx" <<rd<< ", " << I_imm<< ", x" << rs1<< "\n";
                break;
        }
    }
    else if (opcode == 0b0001111) //fence Instructions
    {
        int f1, f2; //new
        f1=(instWord>>24)& 0x0000000F;
        f2=(instWord>>20)& 0X0000000F;
        switch (funct3) {
            case 0b0:
                cout << "\tFENCE\tx" << f1 <<", "<< f2 << "\n";
                break;
            case 0b1:
                cout << "\tFENCE.I\t"<<"\n";
                break;
        }
    }

    else {
        cout << "\tUnkown Instruction \n";
    }

}

int main(int argc, char *argv[]){

    unsigned int instWord=0;
    ifstream inFile;
    ofstream outFile;
    unsigned int pc = 0;

    if(argc<1) emitError("use: disasm <machine_code_file_name>\n");

    inFile.open("parr.bin", ios::in | ios::binary | ios::ate);

    if(inFile.is_open())
    {
        int fsize = inFile.tellg();

        inFile.seekg (0, inFile.beg);
        if(!inFile.read((char *)buffer, fsize)) emitError("Cannot read from input file\n");

        while(true){
            instWord =     (unsigned char)buffer[pc] |
            (((unsigned char)buffer[pc+1])<<8) |
            (((unsigned char)buffer[pc+2])<<16) |
            (((unsigned char)buffer[pc+3])<<24);

            // remove the following line once you have a complete disassembler
            // if(pc==128) break;
            if (instWord==0) break;
            //    cout<<setw(2)<<pc<<":";
            instDecExec(instWord);
            pc += 4;
        }


    } else emitError("Cannot access input file\n");
}
